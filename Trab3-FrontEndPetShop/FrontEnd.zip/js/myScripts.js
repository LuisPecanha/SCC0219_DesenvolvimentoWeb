function servicoSucesso() {
    alert("Serviço agendado com Sucesso!")
}